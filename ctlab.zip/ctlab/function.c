#include<stdio.h>
void sum()
{int a,b,s;
printf("enter a,b values");
scanf("%d %d",&a,&b);
s = a+b;
printf("sum=%d",s);
}


int main()
{sum();
}
