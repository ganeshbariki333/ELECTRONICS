#include <stdio.h>
int main()
{
int num,p,q,r;
printf("enter a number");
scanf("%d",&num);
p=
q=
printf("numext are %d %d",p,q);
r=p;
p=q;
q=r;
printf("after swapping %d %d",p,q);
}
