#include<stdio.h>
int main()
{int n,i;
printf("hnow many numbers do you want");
scanf("%d",&n);
for(i=0;i<=n;i++)
{printf("%d\t",i);
}
}
