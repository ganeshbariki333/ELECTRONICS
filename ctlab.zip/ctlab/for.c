#include<stdio.h>
int main()
{int n,i;
for( ; ; )
{printf("%d",i);
}
}
