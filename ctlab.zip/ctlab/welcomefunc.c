#include<stdio.h>
void welcome();
int main()
{printf("before welcome\n");
welcome();
printf("after welcome\n");
}

void welcome()
{printf("welcome to c\n");
}
